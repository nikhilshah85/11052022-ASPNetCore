﻿namespace employeeManagementAPI.Models
{
    public class EmployeeModel
    {
        #region Properties
        public int Id { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
        public double Salary { get; set; }
        public bool isPermenant { get; set; }
        #endregion

        static List<EmployeeModel> eList = new List<EmployeeModel>()
        {
            new EmployeeModel(){ Id=101, Name = "Rohan", Designation ="Sales", isPermenant=true, Salary=8000},
            new EmployeeModel(){ Id=102, Name = "Mohan", Designation ="HR", isPermenant=true, Salary=8000},
            new EmployeeModel(){ Id=103, Name = "Sohan", Designation ="Sales", isPermenant=false, Salary=8000},
            new EmployeeModel(){ Id=104, Name = "Karan", Designation ="Accounts", isPermenant=true, Salary=8000},
            new EmployeeModel(){ Id=105, Name = "Sumit", Designation ="Sales", isPermenant=true, Salary=8000},
            new EmployeeModel(){ Id=106, Name = "Priya", Designation ="Sales", isPermenant=true, Salary=8000},
            new EmployeeModel(){ Id=107, Name = "Riya", Designation ="Accounts", isPermenant=false, Salary=8000},
            new EmployeeModel(){ Id=108, Name = "Jiya", Designation ="Sales", isPermenant=true, Salary=8000},
            new EmployeeModel(){ Id=109, Name = "Diya", Designation ="Accounts", isPermenant=false, Salary=8000},
        };


        public List<EmployeeModel> AllEmployees()
        {
            return eList;
        }

        public EmployeeModel GetEmployee(int emp_no)
        {
            EmployeeModel emp = (from e in eList
                                 where e.Id == emp_no
                                 select e).Single();
            return emp;
        }
        
        

    }
}
