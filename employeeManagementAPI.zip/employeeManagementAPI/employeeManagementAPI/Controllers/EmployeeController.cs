﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using employeeManagementAPI.Models;
namespace employeeManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        #region GET Methods

        [HttpGet]
        [Route("greet")]
        public IActionResult Greetings()
        {            
            return Ok("Welcome to REST API World");
        }

        [HttpGet]
        [Route("greet/{name}")]
        public IActionResult Greetings(string name)
        {
            return Ok("Hello and how are you "  + name);
        }

        [HttpGet]
        [Route("elist")]
        public IActionResult Employeelist()
        {
            List<string> empLIst = new List<string>();
            empLIst.Add("Sakshi");
            empLIst.Add("Mayuri");
            empLIst.Add("Om");
            empLIst.Add("Rohit");
            empLIst.Add("Akshay");
            empLIst.Add("Rohan");
            empLIst.Add("Mohan"); 
            empLIst.Add("Suresh");
            return Ok(empLIst);
        }
        #endregion

        EmployeeModel empObj = new EmployeeModel();

        [HttpGet]
        [Route("emplist")]
        public IActionResult GetEmployee()
        {
            return Ok(empObj.AllEmployees());
        }
        [HttpGet]
        [Route("emplist/{eId}")]
        public IActionResult GetEmployee(int eId)
        {
            return Ok(empObj.GetEmployee(eId));
        }
    }
}
