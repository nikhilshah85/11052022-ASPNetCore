﻿namespace shoppingAPP.Models
{
    public class ProductsModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public double Price { get; set; }

       static List<ProductsModel> ProductsList = new List<ProductsModel>()
        {

            new ProductsModel() { Id = 101, Name = "Pepsi", Category="Cold-Drinks", Price=50 },
            new ProductsModel() { Id = 102, Name = "Maggi", Category="Fast-food", Price=50 },
            new ProductsModel() { Id = 103, Name = "Tshirt", Category="Clothing", Price=50 },
            new ProductsModel() { Id = 104, Name = "Pasta", Category="Fast-food", Price=50 },
            new ProductsModel() { Id = 105, Name = "Fossil", Category="Watch", Price=50 },
            new ProductsModel() { Id = 106, Name = "IPhone", Category="Electronics", Price=50 },
            new ProductsModel() { Id = 107, Name = "Samsung", Category="Electronics", Price=50 },
        };

        public List<ProductsModel> GetProducts()
        {
            return ProductsList;
        }

        public string AddNewProduct(ProductsModel newProduct)
        {
            //we can pass this newproduct to database
            ProductsList.Add(newProduct);
            return "Product Added Successfully";
        }

    }
}
