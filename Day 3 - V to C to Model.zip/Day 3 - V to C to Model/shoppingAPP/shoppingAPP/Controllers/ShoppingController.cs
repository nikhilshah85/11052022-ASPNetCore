﻿using Microsoft.AspNetCore.Mvc;
using shoppingAPP.Models;
namespace shoppingAPP.Controllers
{
    public class ShoppingController : Controller
    {
        public IActionResult Welcome()
        {
            ViewBag.message = "Welcome to Chrishmas Shopping Fest"; //this valuewill comes Model, Model will take it from database
            ViewBag.discount = "50";
            ViewBag.totalProducts = 5000;
            ViewBag.range = "200 to 10000";


            List<string> productsCategory = new List<string>();
            productsCategory.Add("Clothing");
            productsCategory.Add("Electronics");
            productsCategory.Add("Shoes");
            productsCategory.Add("Accessories");
            productsCategory.Add("Choclates");
            productsCategory.Add("Cold-Drinks");

            ViewBag.productCat = productsCategory;


            return View();
        }

        public IActionResult Products()
        {
            ProductsModel model = new ProductsModel();
            ViewBag.productList = model.GetProducts();
            return View();
        }
        public IActionResult ViewHistory()
        {
            return View();
        }

        [HttpGet]
        public IActionResult AddProduct()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddProduct(ProductsModel newP)
        {
            ProductsModel newProduct = new ProductsModel();
          ViewBag.result =   newProduct.AddNewProduct(newP);
            return View();
        }
    }
}







