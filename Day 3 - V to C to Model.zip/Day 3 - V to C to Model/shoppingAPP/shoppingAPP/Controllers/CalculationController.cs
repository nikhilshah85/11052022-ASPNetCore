﻿using Microsoft.AspNetCore.Mvc;

namespace shoppingAPP.Controllers
{
    public class CalculationController : Controller
    {

        [HttpGet] //httpget is by default
        public IActionResult Greetuser()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Greetuser(string guestName)
        {
            ViewBag.greetMessage = "Welcome " + guestName;           
            return View();
        }
        [HttpGet]
        public IActionResult CalculateNumbers()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CalculateNumbers(int num1, int num2)
        {
            ViewBag.addition = num1 + num2;
            ViewBag.subtraction = num1 - num2;
            ViewBag.division = num1 / num2;
            ViewBag.multiplication = num1 * num2;
            return View();
        }
    }
}
