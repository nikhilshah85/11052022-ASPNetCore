﻿using Microsoft.AspNetCore.Mvc;

namespace firstwebsite.Controllers
{
    public class TrainingController : Controller
    {
      
        public IActionResult trainingInfo()
        {
            //collect the data from model or a view - Not Mandatory
            return View();
        }

        public IActionResult aboutTrainer()
        {
            //collect the data from model or a view - Not Mandatory
            return View();
        }
    }
}
